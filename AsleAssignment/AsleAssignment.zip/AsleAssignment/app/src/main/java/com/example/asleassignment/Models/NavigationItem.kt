package com.example.asleassignment.Models

data class NavigationItem(
    val title: String,
    val iconResId: Int
)
