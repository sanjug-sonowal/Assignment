package com.example.asleassignment.Views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.asleassignment.ApiService
import com.example.asleassignment.R
import com.example.asleassignment.VerifyOtpRequest
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val button = findViewById<Button>(R.id.buttonContinue)
        button.setOnClickListener {

            val retrofit = Retrofit.Builder()
                .baseUrl("https://app.aisle.co/V1/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            val apiService = retrofit.create(ApiService::class.java)

            val number = "+919876543212"
            val otp = "1234"

            val request = VerifyOtpRequest(number, otp)

            runBlocking {
                launch(Dispatchers.IO) {
                    try {
                        val response = apiService.verifyOtp(request)

                        if (response.isSuccessful) {
                            val authToken = response.body()?.authToken

                            // Proceed to Screen 3 passing the authToken as needed
                        } else {
                            // Handle API error response
                        }
                    } catch (e: Exception) {
                        // Handle network or API call failure
                    }
                }
            }


        }
    }
}